<CENTER>
<table border="1px" width="70%" cellpadding="5" cellspacing="0">
<tr>
	<th>No :</th>
	<th>Nama :</th>
	<th>Jabatan</th>
	<th>NO Hp:</th>
</tr>
<tr>
	<td>1.</td>
	<td>TANIA FIRJINIA MAHESSA</td>
	<td>DIREKTUR UTAMA</td>
	<td>082183967221</td>
</tr>
<tr>
	<td>2.</td>
	<td>VIVIN</td>
	<td>WAKIL DIREKTUR</td>
	<td>082234789655</td>
</tr>
<tr>
	<td>3.</td>
	<td>MELINDA</td>
	<td>SEKRETARIS</td>
	<td>082366908712</td>
</tr>
<tr>
	<td>3.</td>
	<td>JOKO JAYA</td>
	<td>BENDAHARA</td>
	<td>082133908311</td>
</tr>

 </table>
</CENTER>